//
//  AddTaskViewController.swift
//  CoreDataSwift
//
//  Created by Harry on 8/30/17.
//  Copyright © 2017 agilepc-159. All rights reserved.
//

import UIKit

class AddTaskViewController: UIViewController {
    
    @IBOutlet weak var taskTextField: UITextField!
    
    var aryTask:[String] = []

    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    @IBAction func buttonTapped(_ sender: UIButton) {

        aryTask.append(taskTextField.text!)

        CoreDataManager.shared.addTask(withData: aryTask)
        
        let _ = navigationController?.popViewController(animated: true)
    }
}
