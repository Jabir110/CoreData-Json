//
//  ViewController.swift
//  CoreDataSwift
//
//  Created by Harry on 8/30/17.
//  Copyright © 2017 agilepc-159. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {

    @IBOutlet weak var tableView: UITableView!

    var tasks: [Task] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.delegate = self
        tableView.dataSource = self
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        
        getData()
        tableView.reloadData()
    }
    
    func getData(){
        tasks = CoreDataManager.shared.getTask()
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return tasks.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        var cell: UITableViewCell! = tableView.dequeueReusableCell(withIdentifier: "cell") as UITableViewCell!
        
        if cell == nil {
            
            cell = tableView.dequeueReusableCell(withIdentifier: "cell")! 
        }
        
        let task = tasks[indexPath.row]
        
        if let myName = task.task_name {
            cell.textLabel?.text = myName
        }
        
        if let myId = task.task_id {
            cell.detailTextLabel?.text = myId
        }

        return cell
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {

        if editingStyle == .delete {
            
            let taskDelete = tasks[indexPath.row]

            CoreDataManager.shared.deleteTaskInCoreData(fromId: taskDelete.task_id!)
            
            getData()
        }
        
        tableView.reloadData()
    }



}

