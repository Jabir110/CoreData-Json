//
//  ModelTask.swift
//  CoreDataSwift
//
//  Created by Harry on 8/31/17.
//  Copyright © 2017 agilepc-159. All rights reserved.
//

import Foundation

class ModelTask: NSObject {
    
    //var activity_id       : Int = 0
    
    var task_id             : String = ""
    var task_name           : String = ""
    
    override init(){
        
        super.init()
    }
    
    init(withCoreDatObjeect object : Task ) {
        super.init()
        
        //self.activity_id  = Int(object.activity_id!)!
        
        self.task_id        = object.task_id!
        self.task_name      = object.task_name!
    }
    
}
